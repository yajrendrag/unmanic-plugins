
**<span style="color:#56adda">0.3.1</span>**
- updated debug message in post processor that Keep streams by language marker written to .unmanic file
- updated comment that above should only occur in unmanic systems prior to existence of the task data store
- all plugin tracking should now be written only to task data store in unmanic ≥ v0.4
- .unmanic files will continue to be checked for history as files could have been processed prior to unmanic v0.4

**<span style="color:#56adda">0.3.0</span>**
- add task data store to store file metadata to use for tracking video files that have had streams kept with this plugin.  plugin will still consult .unmanic files where they exist too.
- Fixed a corner case where a language code accepted by standardize_tag but rejected by is_valid was converted to an empty string, which then raised a LanguageTagError and terminated the plugin
- Fixed if testing a quoted string instead of the keep_original_lang variable, so original-language lookup always ran
- Corrected TMDB read-access-token setting key (tmdb_read_access_token → tmdb_api_read_access_token)
- Added a new tmdb_language_overrides setting (default cn=zh, editable, with inline help); this avoids the TMDB issue where standardize_tag('cn') succeeds and is_valid() rejects 'cn'.
- removed global ALCL variable and moved to a new mapper instance of alcl instead.  this avoids concurrency issues when unmanic could be processing multiple files simultaneously with this plugin.

**<span style="color:#56adda">0.2.3</span>**
- change print statements in lib/tmdb_original.py to logger.info

**<span style="color:#56adda">0.2.2</span>**
- fix add_original_to_alcl function - debug lines at wrong indent

**<span style="color:#56adda">0.2.1</span>**
- size the tmdb attribution logo

**<span style="color:#56adda">0.2.0</span>**
- add options to keep original language via a tmdb lookup
- add tmdb attribution logo assets and NOTICES.md file

**<span style="color:#56adda">0.1.9</span>**
- fix directoryinfo path reference in worker process - it needed to use original file path not file_in as that could be a cache file which would have no directory info

**<span style="color:#56adda">0.1.8</span>**
- fix streams_list function to ignore commentary streams when testing audio streams against config lists.
- change behavior in worker to set a keep_all_audio flag if null test succeeds; then skip keep_audio_langs and just keep all languages; this allows subs to still process
- keep_all_audio will only keep commentary streams if keep_commentary is selected

**<span style="color:#56adda">0.1.7</span>**
- fix null_streams function to remove defunct reference to slcl as null_streams only tests for null intersection of alcl and audio streams in file as of v0.1.6

**<span style="color:#56adda">0.1.6</span>**
- fix issue in if statement when combining test of standardize_tag where langauge could be '*' - separate clauses
- add option to reorder audio streams based on first named langauge - sets first named langauge as default and makes it 1st audio stream
- add option to prefer multichannel or 2 channel when file has multiple streams of first named language
- fix option label description for fail safe to indicate it now only applies to audio streams
- modify description.md to bring up to date with new options

**<span style="color:#56adda">0.1.5</span>**
- change language library from python-iso639 to langcodes
- modify description.md to make it current with options and use of updated langcodes library
- fix description in info.json
- update requirements.txt to refer to langcodes instead of python-iso639

**<span style="color:#56adda">0.1.4</span>**
- add no_work_to_do test to worker process

**<span style="color:#56adda">0.1.3</span>**
- fix no_work_to_do determination when audio_streams_list or subtitle_streams_list are empty

**<span style="color:#56adda">0.1.2</span>**
- fix error in iso language check in stream_tag_language in test streams function (last line wasn't edited properly in cut/paste)

**<span style="color:#56adda">0.1.1</span>**
- add test for None on iso639 Language.match
- update version to 0.1.x series

**<span style="color:#56adda">0.0.35</span>**
- revamp iso639 function to match stream by iso 639 partX type to avoid error by assuming 3 letter codes were part2b vs part2t

**<span style="color:#56adda">0.0.34</span>**
- revise subtitle mapping to include all streams via "-map 0:s?" when "*" specified for subtitle languages
- should avoid error when copying image based subtitle streams

**<span style="color:#56adda">0.0.33</span>**
- fix no_work_to_do - wasn't reaching when one of the language lists in the file was empty
- restored fail safe test to original 'any' based definition - only tests for null intersection of configured languages to keep and actual languages in file

**<span style="color:#56adda">0.0.32</span>**
- added more debug logging for same_streams_or_no_work

**<span style="color:#56adda">0.0.31</span>**
- add check to same_streams expanding the test for no work by identifying scenarios where the only streams to keep are the only ones in the file already whether tagged or untagged

**<span style="color:#56adda">0.0.30</span>**
- fix keep undefined audio_streams_list list builder - improper grouping on last 'or' term

**<span style="color:#56adda">0.0.29</span>**
- fix keep undefined audio_streams_list list builder - last time should have been an 'or'

**<span style="color:#56adda">0.0.28</span>**
- fix fail safe function - it was only working when the config list was shorter than streams list

**<span style="color:#56adda">0.0.27</span>**
- fix fail safe function in worker process
- add iso639 module to convert all language tags to is 639.2b for comparison purposes so user doesn't have to specify both 2 and 3 char language codes
- change fail safe test to find all configured languages are present in the file
- fix mapper.stream_encoding so no extraneous stream copies are in generated ffmpeg command
- fix mapped languages edge case in keep_languages when * is specified and language tags are empty list

**<span style="color:#56adda">0.0.26</span>**
- add an optional fail safe check to prevent unintentional deletion of all audio or subtitle streams - option is on by default

**<span style="color:#56adda">0.0.25</span>**
- fix issue of no audio streams in resulting file when '*' selected and user checked keep undefined

**<span style="color:#56adda">0.0.24</span>**
- fix '*' selector to select all languages to keep

**<span style="color:#56adda">0.0.23</span>**
- fix keep_langues streams_list list generator from falsely removing languages when no title tag exists

**<span style="color:#56adda">0.0.22</span>**
- fix missing character in keep_languages causing error upon loading plugin

**<span style="color:#56adda">0.0.21</span>**
- add option to remove commentary audio streams identified by "commentary" (or "Commentary") in audio title tag

**<span style="color:#56adda">0.0.20</span>**
- change copy streams to copying per stream to a single '-c copy' argument to ffmpeg
- this allows pgs subtitle streams to be copied - copying by stream for pgs subs seems to not work

**<span style="color:#56adda">0.0.19</span>**
- fix keep_languages function to test for non-existent language tags
- change keep_undefined to only include streams without tags or without language tags 

**<span style="color:#56adda">0.0.18</span>**
- fix same_streams function to test for non-existent language tags

**<span style="color:#56adda">0.0.17</span>**
- add code to match all streams; enter * in plugin config language field(s) to keep all streams of desired type

**<span style="color:#56adda">0.0.16</span>**
- fix duplicate stream copying in keep undefined
- modify keep_languages to use exact streams instead of language metadata based stream copying

**<span style="color:#56adda">0.0.15</span>**
- fix bug in keep_undefined by refactoring & properly identify specific audio/subtitle stream being mapped and copied

**<span style="color:#56adda">0.0.14</span>**
- fix file_streams_already_kept to remove reference to unused option - ignore_previously_processed

**<span style="color:#56adda">0.0.13</span>**
- fix logger reference to keep_streams vs remove_streams

**<span style="color:#56adda">0.0.12</span>**
- include use of .unmanic file to track files whose streams were previously kept by this plugin to prevent re-adding task to task queue

**<span style="color:#56adda">0.0.11</span>**
- add option to keep streams with no language tags or undefined values

**<span style="color:#56adda">0.0.10</span>**
- fix broken filter from previous step

**<span style="color:#56adda">0.0.9</span>**
- add filter to remove language from configured languages if it doesn't appear in any of a file's streams

**<span style="color:#56adda">0.0.8</span>**
- fix additional file test for duplicate language streams

**<span style="color:#56adda">0.0.7</span>**
- correct logger identification

**<span style="color:#56adda">0.0.6</span>**
- add additional file test to skip file if all configured streams are the only streams present in file

**<span style="color:#56adda">0.0.5</span>**
- correct verbiage in config options to show multiple languages can be accepted

**<span style="color:#56adda">0.0.4</span>**
- fix keep function stream_encoding additions

**<span style="color:#56adda">0.0.3</span>**
- update stream encodings & mappings to only map & copy specifc streams

**<span style="color:#56adda">0.0.2</span>**
- update metadata maps to use optional map syntax

**<span style="color:#56adda">0.0.1</span>**
- Process audio and subtitles
- Based on Remove Streams by Language v0.0.5
