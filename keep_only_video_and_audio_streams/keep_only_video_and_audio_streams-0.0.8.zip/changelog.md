
**<span style="color:#56adda">0.0.8</span>**
- use a python_command variable to make init.d script work on venv and non-venv systems

**<span style="color:#56adda">0.0.7</span>**
- remove requirements.txt content
- change to init.d based plugin installation
- add missing LICENSE file

**<span style="color:#56adda">0.0.6</span>**
- specify numpy version

**<span style="color:#56adda">0.0.5</span>**
- add missing import statement

**<span style="color:#56adda">0.0.4</span>**
- add a synchronized subtitle for each extracted subtitle file

**<span style="color:#56adda">0.0.3</span>**
- correction to save each subtitle stream as individual file

**<span style="color:#56adda">0.0.2</span>**
- added option to extract & convert all subs to srt files in original directory

**<span style="color:#56adda">0.0.1</span>**
- Initial version
