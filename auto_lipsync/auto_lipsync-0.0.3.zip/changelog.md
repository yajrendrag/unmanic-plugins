
**<span style="color:#56adda">0.0.3</span>**
- updated dependencies installer for syncnet

**<span style="color:#56adda">0.0.2</span>**
- added icon

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- SyncNet with S3FD face detection for automatic lip sync offset detection
- ffmpeg itsoffset correction (stream copy, no re-encoding)
- Configurable minimum/maximum offset and confidence thresholds
- File metadata tracking to avoid re-processing
