
---

##### Links:

- [Support](https://unmanic.app/discord)

---

##### Description:
This plugin forces the file to be processed.  Use it if you want to add a file to the processing queue without any testing.
Place it after other limit/exclude plugins if you want to filter out certain types of files.
---

##### Documentation:

### Config description:

#### <span style="color:blue">Custom Metadata</span>
Enter custom tags as tagname:value (no spaces), enter more than one pair by delimiting pairs with commas

:::note
:::
