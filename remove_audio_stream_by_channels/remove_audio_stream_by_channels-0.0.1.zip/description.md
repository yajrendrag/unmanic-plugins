
Enter the maximum number of audio channels per stream.  Streams with greater than this
number will be deleted.  All other streams will be copied.
---

#### Examples:

###### <span style="color:magenta">Specified max channels of 2</span>
```
2
```
