#!/bin/bash
# Install Python dependencies for rename_file

/opt/venv/bin/python3 -m pip install --cache-dir /config/.cache/pip parse-torrent-title
