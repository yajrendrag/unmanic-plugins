
**<span style="color:#56adda">0.0.2</span>**
- add -map 0 so it doesn't resort to default mapping and maps all streams

**<span style="color:#56adda">0.0.1</span>**
- initial release
