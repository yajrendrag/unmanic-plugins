
**<span style="color:#56adda">0.0.4</span>**
- version number change

**<span style="color:#56adda">0.0.3</span>**
- remove default audio disposition settings and make new 1st audio stream the default
- fix astream_ordering logic

**<span style="color:#56adda">0.0.2</span>**
- fix sory to sort

**<span style="color:#56adda">0.0.1</span>**
- initial release
