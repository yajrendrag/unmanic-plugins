
**<span style="color:#56adda">0.0.1</span>**
- initial version
- Based on v0.0.4 of Josh's Limit Library Search by File Extension
