
**<span style="color:#56adda">0.0.2</span>**
- use explicit stream mapping

**<span style="color:#56adda">0.0.1</span>**
- initial release
- based on add_extra_multichannel_audio
