
**<span style="color:#56adda">0.0.3</span>**
- fix library call in plugin.py

**<span style="color:#56adda">0.0.2</span>**
- use yajrendrag lib/ffmpeg helper lib - allows extra encoders in custom options

**<span style="color:#56adda">0.0.1</span>**
- based off of v0.0.5 of AAC encoder
- modified original AAC encoder to use libfdk_aac - which is in jellyfin_ffmpeg5
