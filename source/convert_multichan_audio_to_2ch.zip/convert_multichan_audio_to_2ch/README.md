# Convert Multichannel Audio streams to 2 channel stereo streams
Plugin for [Unmanic](https://github.com/Unmanic)

---

### Information:

- [Description](description.md)
- [Changelog](changelog.md)
