
**<span style="color:#56adda">0.0.3</span>**
- use threading to add the task back to the task list
- necessary in the case where the file name remains identical to the filename in the original task - so old task is detected as deleted

**<span style="color:#56adda">0.0.2</span>**
- updated description.md to explain the additional options

**<span style="color:#56adda">0.0.1</span>**
- Initial version
