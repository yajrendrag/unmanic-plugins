
**<span style="color:#56adda">0.0.3</span>**
- Use a different jsonata library that provides better stability                 
- improve consistency across all unmanic plugins by using same jsonata library

**<span style="color:#56adda">0.0.2</span>**
- updated requirements.txt to remove version numbers so compatible with latest or staging tags (different pythong versions)

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- Mediainfo version of Ignore Files based on metadata
