
##### Links:

- [Support](https://unmanic.app/discord)

---


##### Description
This plugin will add mkv track statistics tags to a file and if the file already has them, it will update them.
---

#### Config description:

This plugin has no required configuration.
