# Remove subtitle data streams

plugin for [Unmanic](https://github.com/Unmanic)
