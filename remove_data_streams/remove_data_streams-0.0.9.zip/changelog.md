
**<span style="color:#56adda">0.0.9</span>**
- change -map_metadata:c to -map_metadata

**<span style="color:#56adda">0.0.8</span>**
- add test to ensure ffprobe fields exist in test_stream_needs_processing function

**<span style="color:#56adda">0.0.7</span>**
- fix error test in probe.py & update to forked
  unmanic.plugin.helpers.ffmpeg repo

**<span style="color:#56adda">0.0.6</span>**
- add codec_type test in class PluginStreamMapper

**<span style="color:#56adda">0.0.5</span>**
- add advanced ffmpeg option

**<span style="color:#56adda">0.0.4</span>**
- correct PluginStreamMapper type

**<span style="color:#56adda">0.0.3</span>**
- update codec_name values

**<span style="color:#56adda">0.0.2</span>**
- fix library include

**<span style="color:#56adda">0.0.1</span>**
- Initial Version
- Based on Josh's remove_image_subtitles v.0.04
