This plugin removes all subtitle datastreams that are identified
by having ffprobe metadata handler_name with value of SubtitleHandler
	
