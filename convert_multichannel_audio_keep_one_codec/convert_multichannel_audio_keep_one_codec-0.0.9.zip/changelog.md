
**<span style="color:#56adda">0.0.9</span>**
- prevent file being unnecessarily reencoded if a stream's encoder is already the designated encoder

**<span style="color:#56adda">0.0.8</span>**
- added logger output in s2_encode

**<span style="color:#56adda">0.0.7</span>**
- typo in settings.get_settings -> settings.get_setting

**<span style="color:#56adda">0.0.6</span>**
- add settings to s2_encode function

**<span style="color:#56adda">0.0.5</span>**
- added option to keep or discard commentary streams

**<span style="color:#56adda">0.0.4</span>**
- fix GUI config format => form

**<span style="color:#56adda">0.0.3</span>**
- fix if statement

**<span style="color:#56adda">0.0.2</span>**
- fix if statement

**<span style="color:#56adda">0.0.1</span>**
- initial release
- based on convert_multichannel_audio_to_aac_or_ac3
