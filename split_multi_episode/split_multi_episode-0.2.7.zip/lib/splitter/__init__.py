#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .episode_splitter import EpisodeSplitter

__all__ = ['EpisodeSplitter']
