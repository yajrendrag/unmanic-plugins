#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .tmdb_validator import TMDBValidator

__all__ = ['TMDBValidator']
