
**<span style="color:#56adda">0.0.4</span>**
- typo in description.md (info page)

**<span style="color:#56adda">0.0.3</span>**
- add file_path to file_contains_disallowed_values function parameters

**<span style="color:#56adda">0.0.2</span>**
- add ffmpeg-python to requirements.txt

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- jsonata version of ignore_files_based_on_metadata
