
**<span style="color:#56adda">0.1.0</span>**
- add codec_name:encoder dictionary for use in streams_to_encode stream test
- add debug output in s2_encode

**<span style="color:#56adda">0.0.4</span>**
- fix erroneous reference to force_encoder

**<span style="color:#56adda">0.0.3</span>**
- added force encoding option
- added check so file not reprocessed if stream encoder equals configured encoder

**<span style="color:#56adda">0.0.2</span>**
- Added new "Default/None" option which doesn't set a bitrate (and uses the codec default)
- Changed codec names
- Changed Default settings
- (Opus and Vorbis don't work with cover art yet, coming soon™)

**<span style="color:#56adda">0.0.1</span>**
- initial version
