
**<span style="color:#56adda">0.0.5</span>**
- corrected text on add to queue block label
- changed crop test condition to OR so only vertical or horizontal bars need to exist, not both
- added additional debug output

**<span style="color:#56adda">0.0.4</span>**
- add option to set to False adding file to queue so no library plugins can add the file to the queue if it does not have black bars

**<span style="color:#56adda">0.0.3</span>**
- extract element 0 from width & height

**<span style="color:#56adda">0.0.2</span>**
- input_file -> abspath

**<span style="color:#56adda">0.0.1</span>**
- initial release
