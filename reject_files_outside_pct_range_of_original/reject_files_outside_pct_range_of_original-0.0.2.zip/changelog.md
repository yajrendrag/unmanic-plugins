
**<span style="color:#56adda">0.0.2</span>**
- updated description

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- Based on reject_files_larger_than_original v0.0.4
- adds a configurable range for file size expressed as percentages of original size
